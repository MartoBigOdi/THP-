package mis_ejercicios;

public class Ejercicio2 {

	public static void main(String[] args) {
		
		int num1 = 4, num2 = 5;
		
		int suma = num1 + num2;
		
		int mult = num1 * num2;
		
		System.out.println("Esta es la suma de "+num1 +" + "+num2 +" = "+ suma  +" y la multiplicaión de " + num1 + " * " + num2 + " = " + mult);
		
		
		
		
	}

}
