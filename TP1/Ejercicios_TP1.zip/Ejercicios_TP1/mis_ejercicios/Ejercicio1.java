package mis_ejercicios;

public class Ejercicio1 {

	public static void main(String[] args) {
		
		int num1 = 0;
		    num1 = +2;
		    
		int mult = num1 * num1;
		
		System.out.println(mult);
		

	}

}
